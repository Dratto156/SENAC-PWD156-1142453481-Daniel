function Cad () {
    return (
            <div> 
                <h1>Pagina de Cadastro do Cliente</h1><br/>
            </div>
    )
}
export default Cad;