function Calculo () {
    return (
            <div>
                <h1>Pagina relacionada ao Calculo do Financiamento</h1><br/>
            </div>

    )
}
export default Calculo;