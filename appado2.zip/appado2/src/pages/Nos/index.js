function Nos () {
    return (
            <div> 
                <h1>Página sobre a empresa</h1>
            </div>
    )
}
export default Nos;