/*  * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*         SENAC - TADS - Programacao Web *
*     ADO #02 Trabalhando As Rotas e LINKS *
* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
*     Nome : <<     Daniel Richard    > > 
* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

import RoutesApp from './route';

function App() {
  return (
    <RoutesApp/>
  );
}

export default App;
