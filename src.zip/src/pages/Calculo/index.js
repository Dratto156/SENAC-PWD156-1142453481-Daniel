import { Link } from 'react-router-dom';
function Calculo () {
    return (
            <div>
                <h1>Pagina Calculo do Financiamento</h1>
                <Link to='/'>Home</Link><br/>
            </div>

    )
}
export default Calculo;